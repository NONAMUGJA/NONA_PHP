<?php
    // 설정
    $uploads_dir = 'uploads';
    $allowed_ext = array('jpg','jpeg','png','gif');
    
    // 변수 정리
    $error = $_FILES['myfile']['error'];
    $name = $_FILES['myfile']['name'];
    $ext = array_pop(explode('.', $name));
    
    // 오류 확인
    if( $error != UPLOAD_ERR_OK ) {
        switch( $error ) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                echo "File Too Large";
                break;
            case UPLOAD_ERR_NO_FILE:
                echo "File Did Not Uploaded";
                break;
            default:
                echo "File Upload Failure";
        }
        exit;
    }
    
    // 확장자 확인
    if( !in_array($ext, $allowed_ext) ) {
        echo "Ext Not Allowed";
        exit;
    }
    
    // 파일 이동
    $cryptedHash = str_replace("/", "!", crypt($name));
    move_uploaded_file( $_FILES['myfile']['tmp_name'], $uploads_dir."/".$cryptedHash.".".$ext);

    // 파일 정보 출력
    echo "http://".$_SERVER['SERVER_NAME']."/nona/storage/img/".$uploads_dir."/".$cryptedHash.".".$ext;
?>