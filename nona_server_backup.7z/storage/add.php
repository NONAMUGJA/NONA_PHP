<?php
    $no = $_GET["no"];
    $sender = $_GET["sender"];
    $imageId = $_GET["imageId"];
    $itemTitle = $_GET["itemTitle"];
    $count = $_GET["count"];
    $lockpw = $_GET["lockpw"];
    $comment = $_GET["comment"];
    $receiver = $_GET["receiver"];

    $data = file_get_contents('data.json');
    $json_arr = json_decode($data, JSON_UNESCAPED_UNICODE);
    
    $json_arr[$no]["reg_time"] = date("Y-m-d H:i:s");
    $json_arr[$no]["sender"] = $sender;
    $json_arr[$no]["imageId"] = $imageId;
    $json_arr[$no]["itemTitle"] = $itemTitle;
    $json_arr[$no]["count"] = $count;
    $json_arr[$no]["lockpw"] = $lockpw;
    $json_arr[$no]["comment"] = $comment;
    $json_arr[$no]["receiver"] = $receiver;
    $jsonFile = fopen("data.json", "w") or die("ERROR");
    fwrite($jsonFile, json_encode($json_arr, JSON_UNESCAPED_UNICODE));
    fclose($jsonFile);

    echo "SUCCESS";
?>
