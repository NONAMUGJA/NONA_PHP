<?php
	header("Content-type: application/json");
	$fp = fopen("data.json", "r");
	fpassthru($fp); 
    flush(); 
    fclose($fp);
?>
