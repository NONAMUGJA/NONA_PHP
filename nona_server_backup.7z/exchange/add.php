<?php
    $no = $_GET["no"];
    $receiver = $_GET["receiver"];
    $chgProduct = $_GET["chgProduct"];
    $quantity = $_GET["quantity"];
    $comment = $_GET["comment"];

    $data = file_get_contents('data.json');
    $json_arr = json_decode($data, JSON_UNESCAPED_UNICODE);
    
    $json_arr[$no]["reg_time"] = date("Y-m-d H:i:s");
    $json_arr[$no]["receiver"] = $receiver;
    $json_arr[$no]["chgProduct"] = $chgProduct;
    $json_arr[$no]["quantity"] = $imageId;
    $json_arr[$no]["comment"] = $itemTitle;
    $jsonFile = fopen("data.json", "w") or die("ERROR");
    fwrite($jsonFile, json_encode($json_arr, JSON_UNESCAPED_UNICODE));
    fclose($jsonFile);

    echo "SUCCESS";
?>
