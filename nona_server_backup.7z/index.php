<?php
	echo "NONA Base Directory\nServer Running";
?>
